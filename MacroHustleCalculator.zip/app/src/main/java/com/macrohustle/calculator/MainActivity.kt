package com.macrohustle.calculator

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // How many days one "period" lasts. Used to turn any amount into a daily cost.
    private class Period(val label: String, val days: Double)

    private class Category(val name: String, val defaultPeriod: Int)

    private val periods = listOf(
        Period("Per day", 1.0),
        Period("Per week", 7.0),
        Period("Per month", 365.0 / 12.0),
        Period("Per term (3 a year)", 365.0 / 3.0),
        Period("Per year", 365.0)
    )

    private val categories = listOf(
        Category("Food", 0),
        Category("School fees", 3),
        Category("House rent", 2),
        Category("Basic expenses", 0)
    )

    private val amountFields = ArrayList<EditText>()
    private val periodSpinners = ArrayList<Spinner>()

    private lateinit var etCurrency: EditText
    private lateinit var resultCard: LinearLayout
    private lateinit var tvDaily: TextView
    private lateinit var tvOthers: TextView
    private lateinit var tvBreakdown: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etCurrency = findViewById(R.id.etCurrency)
        resultCard = findViewById(R.id.resultCard)
        tvDaily = findViewById(R.id.tvDaily)
        tvOthers = findViewById(R.id.tvOthers)
        tvBreakdown = findViewById(R.id.tvBreakdown)

        val container = findViewById<LinearLayout>(R.id.expenseContainer)
        val inflater = LayoutInflater.from(this)
        val labels = periods.map { it.label }

        for (cat in categories) {
            val row = inflater.inflate(R.layout.item_expense, container, false)
            row.findViewById<TextView>(R.id.tvLabel).text = cat.name

            val amount = row.findViewById<EditText>(R.id.etAmount)
            val spinner = row.findViewById<Spinner>(R.id.spPeriod)

            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = adapter
            spinner.setSelection(cat.defaultPeriod)

            container.addView(row)
            amountFields.add(amount)
            periodSpinners.add(spinner)
        }

        findViewById<Button>(R.id.btnCalculate).setOnClickListener { calculate() }
        findViewById<Button>(R.id.btnReset).setOnClickListener { reset() }
    }

    private fun money(value: Double): String {
        val symbol = etCurrency.text.toString().trim()
        return symbol + String.format(Locale.US, "%,.2f", value)
    }

    private fun calculate() {
        var dailyTotal = 0.0
        val breakdown = StringBuilder()

        for (i in categories.indices) {
            val raw = amountFields[i].text.toString().replace(",", "").trim()
            val amount = raw.toDoubleOrNull() ?: 0.0
            val period = periods[periodSpinners[i].selectedItemPosition]
            val daily = amount / period.days
            dailyTotal += daily
            breakdown.append(categories[i].name)
                .append(": ")
                .append(money(daily))
                .append(" / day\n")
        }

        val weekly = dailyTotal * 7.0
        val monthly = dailyTotal * 365.0 / 12.0
        val yearly = dailyTotal * 365.0

        tvDaily.text = money(dailyTotal) + " a day"
        tvOthers.text = "Per week:  " + money(weekly) + "\n" +
            "Per month:  " + money(monthly) + "\n" +
            "Per year:  " + money(yearly)
        tvBreakdown.text = breakdown.toString().trimEnd()

        resultCard.visibility = View.VISIBLE

        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0) }
    }

    private fun reset() {
        for (i in categories.indices) {
            amountFields[i].setText("")
            periodSpinners[i].setSelection(categories[i].defaultPeriod)
        }
        resultCard.visibility = View.GONE
    }
}
